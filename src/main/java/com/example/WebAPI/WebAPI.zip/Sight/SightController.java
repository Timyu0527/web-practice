package com.example.WebAPI.Sight;

import com.example.WebAPI.KeelungSightsCrawler.KeelungSightsCrawler;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public class SightController {

    @GetMapping("SightAPI")
    public Sight[] getSights(@RequestParam("zone") String zone){
        KeelungSightsCrawler crawler = new KeelungSightsCrawler();
        Sight[] sights = crawler.getItem(zone);
        return sights;
    }
}
