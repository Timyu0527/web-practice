package com.example.WebAPI.KeelungSightsCrawler;

import com.example.WebAPI.Sight.Sight;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.*;

public class KeelungSightsCrawler {
    private String url;
    private Map<String, Sight[]> allSights;
    private Map<String, ArrayList<String> > allSightsURLs;
    public KeelungSightsCrawler(){
        this.allSights = new Hashtable<String, Sight[]>();
        this.allSightsURLs = new Hashtable<String, ArrayList<String> >();
        this.url = "https://www.travelking.com.tw";
    }
    private void getAllSightURLs(){
        ArrayList<String> urls = new ArrayList<String>();
        try {
            final Document document = Jsoup.connect(url + "/tourguide/taiwan/keelungcity/").get();
            for(Element ele : document.select("div.box h4")){
                Element sight = ele.nextElementSibling();
                String zone = ele.text().substring(0, ele.text().length() - 1);
                for(Element sightURL : sight.select("li a")){
                    urls.add(sightURL.attr("href"));
                }
                this.allSightsURLs.put(zone, new ArrayList<String>(urls));
                urls.clear();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private String getPhotoURL(Document document){
        if(document.select("div.gpic img").isEmpty()) return "";
        Element photoURL = document.select("div.gpic img").get(0);
        return photoURL.attr("data-src");
    }
    private String getDescription(Document document){
        if(document.select("div.text").isEmpty()) return "";
        Element content = document.select("div.text").get(0);
        StringBuilder elementToString = new StringBuilder();
        return content.text();
    }
    private String getCategory(Document document){
        if(document.select("cite span strong").isEmpty()) return "";
        Element content = document.select("cite span strong").get(0);
        return content.text();
    }
    private String getSightName(Document document){
        if(document.select("h1.h1").isEmpty()) return "";
        Element content = document.select("h1.h1").get(0);
        return content.text();
    }
    private String getAddress(Document document){
        if(document.select("div.address p").isEmpty()) return "";
        Element content = document.select("div.address p").get(0);
        return content.text();
    }
    public Sight[] getItem(String zone){
        if(this.allSightsURLs.isEmpty()) getAllSightURLs();
        if(this.allSights.containsKey(zone)) return this.allSights.get(zone);
        try {
            final Document document = Jsoup.connect(url + "/tourguide/taiwan/keelungcity/").get();
            for(Element row : document.select("div.box h4")){
                String sight = row.text().substring(0, row.text().length() - 1);
                Sight[] sightInfo = getSightsInfo(sight);
                this.allSights.put(sight, sightInfo);
            }
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
        return this.allSights.get(zone);
    }
    private Sight[] getSightsInfo(String zone){
        ArrayList<String> sightURLs = this.allSightsURLs.get(zone);
        Sight[] sights = new Sight[sightURLs.size()];
        int size = 0;
        for(String sightURL : sightURLs){
            try{
                final Document document = Jsoup.connect(url + sightURL).get();
                String sightName = getSightName(document);
                String category = getCategory(document);
                String photoURL = getPhotoURL(document);
                String description = getDescription(document);
                String address = getAddress(document);
                sights[size++] = new Sight(sightName, photoURL, address, zone, category, description);
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }
        return sights;
    }
}
